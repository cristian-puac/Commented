#pragma once
#ifndef FLIP_HORIZONTALLY_EFFECT_H
#define FLIP_HORIZONTALLY_EFFECT_H
#include "Pixel.h"
#include "ImageEffect.h"

// this image effect will horizontally flip the image to mirror the
// original ppm document
class FlipHorizontallyImageEffect : public ImageEffect
{
	virtual void processImage(PpmDocument &doc)
	{
		for (int i = 0; i < doc.getHeight(); i++)
		{
			for (int j = 0; j < doc.getWidth()/2; j++)
			{
				int column_num = doc.getWidth() - j - 1;
				Pixel& p = doc.getPixel(i, j);
				Pixel& temp = doc.getPixel(i, column_num);
				swap(p, temp);
			}

			
		}
	}
};

#endif