#pragma once
#ifndef FLIP_VERTICALLY_EFFECT_H
#define FLIP_VERTICALLY_EFFECT_H
#include "Pixel.h"
#include "ImageEffect.h"

// this image effect will vertically flip the image to mirror the
// original ppm document
class FlipVerticallyImageEffect : public ImageEffect
{
	virtual void processImage(PpmDocument &doc)
	{
		for (int i = 0; i < doc.getHeight() / 2; i++)
		{
			for (int j = 0; j < doc.getWidth(); j++)
			{
				int column_num = doc.getHeight() - i - 1;
				Pixel& p = doc.getPixel(i, j);
				Pixel& temp = doc.getPixel(column_num, j);
				swap(p, temp);
			}

		}
	}
};

#endif